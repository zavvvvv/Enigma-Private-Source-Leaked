#pragma once
#ifndef DRAW
#define DRAW

#include "../../../../includes.hpp"

namespace v
{
	class draw
	{
	public:

	};
}
static v::draw* draw = new v::draw();

#endif
